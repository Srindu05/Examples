package com.placement.placementmanagement.controller;

import com.placement.placementmanagement.entity.Admin;
import com.placement.placementmanagement.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class AdminController {

    @Autowired
    private AdminService adminService;

    // Home page
    @GetMapping("/")
    public String home() {
        return "index"; // index.html
    }

    // View all admins
    @GetMapping("/AdminPage")
    public String viewAdmins(Model model) {
        List<Admin> admins = adminService.getAllAdmins();
        model.addAttribute("admins", admins);
        model.addAttribute("admin", new Admin()); // For add form
        return "admin"; // admin.html
    }

    // Add new admin
    @PostMapping("/addAdmin")
    public String addAdmin(@ModelAttribute Admin admin, RedirectAttributes redirectAttrs) {
        adminService.saveAdmin(admin);
        redirectAttrs.addFlashAttribute("message", "Admin added successfully!");
        return "redirect:/AdminPage";
    }

    // Edit existing admin page
    @GetMapping("/editAdmin/{id}")
    public String editAdmin(@PathVariable Long id, Model model) {
        Admin admin = adminService.getAdminById(id);
        model.addAttribute("admin", admin);
        return "admin_edit"; // admin_edit.html
    }

    // Update admin
    @PostMapping("/updateAdmin")
    public String updateAdmin(@ModelAttribute Admin admin) {
        adminService.saveAdmin(admin);
        return "redirect:/AdminPage";
    }

    // Delete admin
    @GetMapping("/deleteAdmin/{id}")
    public String deleteAdmin(@PathVariable Long id) {
        adminService.deleteAdmin(id);
        return "redirect:/AdminPage";
    }
}
